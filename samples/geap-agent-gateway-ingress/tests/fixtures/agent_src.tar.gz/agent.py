"""ADK agent answering with Claude on Vertex AI, served behind an ingress Agent Gateway (Model Armor)."""

import time
from typing import Any

from anthropic.lib.vertex import AsyncAnthropicVertex
from google.adk.agents import LlmAgent
from google.adk.models.anthropic_llm import Claude
from vertexai.agent_engines import AdkApp

from config import Config, load_config
from logger import get_logger

logger = get_logger("agent")

INSTRUCTION = "You are a concise assistant. Answer the user's question in a few sentences."
# Upper bound of one answer, to bound the cost of a call
MAX_OUTPUT_TOKENS = 1024

# Start time of each in-flight model call, keyed by invocation, to log its duration.
_started: dict[str, float] = {}


def _before_model(callback_context: Any, llm_request: Any) -> None:
    _started[callback_context.invocation_id] = time.monotonic()


def _after_model(callback_context: Any, llm_response: Any) -> None:
    """Log token usage and duration of every LLM call."""
    started = _started.pop(callback_context.invocation_id, None)
    duration_ms = int((time.monotonic() - started) * 1000) if started is not None else -1
    usage = getattr(llm_response, "usage_metadata", None)
    logger.info(
        "llm_call duration_ms=%d prompt_tokens=%s output_tokens=%s total_tokens=%s",
        duration_ms,
        getattr(usage, "prompt_token_count", None),
        getattr(usage, "candidates_token_count", None),
        getattr(usage, "total_token_count", None),
    )


def build_agent(config: Config) -> LlmAgent:
    """Build the agent; transient model errors (429, 5xx) are retried by the Anthropic client."""
    model = Claude(
        model=config.model,
        max_tokens=MAX_OUTPUT_TOKENS,
        # Model location (EU) for this client only, independent of the engine region
        client=AsyncAnthropicVertex(project_id=config.project, region=config.location, max_retries=3, timeout=60.0),
    )
    return LlmAgent(
        name="ingress_agent",
        description="Answers simple questions with Claude.",
        model=model,
        instruction=INSTRUCTION,
        before_model_callback=_before_model,
        after_model_callback=_after_model,
    )


class ScreenedAdkApp(AdkApp):
    """AdkApp exposing a single method: async_stream_query.

    Model Armor screens client-to-agent traffic for reasoningEngines.streamQuery requests of ADK agents only. The
    other AdkApp methods that run the agent (stream_query, streaming_agent_run_with_events) would be ways to reach
    the model without that screening, and the session methods are not needed by the clients of this sample.
    """

    def register_operations(self) -> dict[str, list[str]]:
        return {"async_stream": ["async_stream_query"]}


# `root_agent` is what ADK tooling (adk web, evals) loads.
root_agent = build_agent(load_config())

# Agent Runtime serves an object that exposes query methods: a bare LlmAgent fails to start. This is the
# entrypoint of the Terraform python_spec.
adk_app = ScreenedAdkApp(agent=root_agent)
